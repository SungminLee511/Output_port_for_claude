# HL-Mando GEO04 — solve all 20 BC samples (PLAN)

## Goal
Solve **every** GEO04_BC01…BC20 H5 sample with the MESHnSOLVERS contact solver
and compare against ground-truth displacement (`DISP[:,10]`). Per-sample
parameter tweaks are allowed (multiple runs); generality is **not** required.
Deliverables: a metrics markdown (GT vs solved) + a per-sample point-cloud
comparison picture, all under `TRASHCAN/mando_solve/`.

## What is fixed vs tuned
All 20 files share the **same GEO04 mesh** (193 965 nodes, identical
connectivity, same 2 contact pairs). Only the boundary condition differs per
file: `loaded_force`, `Fixed_one_hot`, `Rubber_fixed`. `mando_loader.load_case`
maps each correctly; `contact_pairs_v2.npz` is mesh-fixed and reused for all.

**Fixed recipe** (validated on BC01/BC05 in the prior campaign — see
`CAMPAIGN_LOG.md`):
- Augmented-Lagrange (Uzawa) normal contact, `contact_epsilon = 5e4`,
  `al_max_outer = 2`, `al_gap_tol = 1e-4`.
- Penalty friction `mu = 0.07`.
- `n_load_steps = 2`, `nr_max = 15`.
- Linear solver = AMG-PCG (`linear_solver="amg"`, `max_iter=300`).
- Rubber pad modelled as **compliant spring-to-ground** on `Rubber_fixed`
  nodes (`material["spring_nodes"]`, `material["spring_k"]`) — NOT a rigid BC.

**Only tuned per sample:** the rubber spring stiffness `k` (N/mm/node). This is
the single knob that sets deflection magnitude; direction already generalises
(dir-cos ≥ 0.9 everywhere). Calibration is **GT-informed** (allowed by user).

## Why k must be calibrated
The rubber pad is given only as a 0/1 mask — no stiffness value. The prior
campaign found a single k=5 fits BC01-level loads (BC01, BC05 → rel-L2 ≈ 0.25),
but heavier loads (BC02, BC10) over-deflect ~2.3–2.7×. So k is calibrated per
BC against GT magnitude.

### Calibration model (`calibrate.py`)
Let r(k) = |u_solved| / |u_gt| ≈ 1/best_scale. Model
`r(k) = a + b/k` (a = structural compliance, b/k = pad compliance).
- **1 data point:** assume a≈0 → `k_next = k · r = k / best_scale`.
- **≥2 points:** fit a,b from the last two rounds, solve r=1 →
  `k_next = b / (1 − a)`. Clamp k ∈ [1, 2000].

Target: rel-L2 (free DOFs) ≤ 0.30. Cap at 3 rounds per BC; if a BC still misses
on raw rel-L2 it is reported with its best-scale-corrected rel-L2 (honest:
magnitude-only residual = a single missing material constant).

## Pipeline (scripts/)
1. `mando_loader.py` — H5 → solver inputs (force/fixed/material/tet/GT).
2. `build_contact_v2.py` — (re)builds `results/contact_pairs_v2.npz` (mesh-fixed).
3. `solve_batch.py --job jobs/<tag>.json` — solves each BC in the job at its k,
   saves `results/<bc>_<tag>.json` + `_fields.npz`. Resumable (skips done).
4. `calibrate.py <next_tag>` — reads all rounds, writes `jobs/<next_tag>.json`
   with the BCs still missing target and their proposed k. Prints `ALL-PASS`
   when every BC ≤ 0.30.
5. `make_report.py` — picks the best round per BC, writes `RESULTS.md` (metric
   table) and `figures/<bc>_cloud.png` (GT vs solver vs error point clouds).

## Execution (relay)
- **Round 1:** 16 remaining BCs at k=5 (BC01/02/05/10 already solved, reused as
  `*_r1`). One nohup process, ~45 min/solve ≈ ~12 h. Pattern-A wakes monitor
  `solve_r1.log` progress (count `[done]` lines / 16).
- **Round 2:** `calibrate.py r2` → solve misses at corrected k. ~10–14 BCs.
- **Round 3:** `calibrate.py r3` if needed.
- **Finalise:** `make_report.py` → `RESULTS.md` + 20 cloud pngs. Push summary
  figure + report to output_port.

Estimated wall time: ~24–36 h serial on one A100 (≈45 min/solve, ~35–45 solves
total across rounds). Runs unattended via the relay.

## Status
- [x] Folder created, old plan → `CAMPAIGN_LOG.md`, loose dev scripts deleted.
- [x] BC01/02/05/10 solved (k=5) → reused as round-1 results.
- [ ] Round 1: BC03,04,06,07,08,09,11–20 at k=5.
- [ ] Round 2/3: per-BC k calibration on misses.
- [ ] `make_report.py` → RESULTS.md + 20 point-cloud figures.

## Layout
```
mando_solve/
├── PLAN.md            (this file)
├── CAMPAIGN_LOG.md    (prior BC01 breakthrough campaign log)
├── RESULTS.md         (generated: metrics table + figure links)
├── scripts/           (loader, solve_batch, calibrate, make_report, build_contact)
├── jobs/              (per-round job JSONs)
├── results/           (<bc>_r<n>.json + _fields.npz, contact_pairs_v2.npz)
└── figures/           (<bc>_cloud.png per sample)
```
