"""HL-Mando GEO04 H5 -> MESHnSOLVERS solver-input loader.

Mapping decisions (per HL_MANDO_SOLVE_PLAN.md):
  - force      <- loaded_force (pre-distributed nodal force on solid nodes)
  - fixed      <- Fixed_one_hot[:, :3]  (optionally + Rubber_fixed)
  - elements   <- tet4 (C3D4)
  - material   <- per-node Material_E/nu -> per-tet (single aluminum)
  - dim = 3, drop beams/connector rig
"""
import h5py
import numpy as np
import torch

H5DIR = "/home/sky/home/TRASHCAN/data_port/hl-mando"


def load_case(bc="BC01", include_rubber_fixed=False, pin_isolated=True,
              device="cpu", dtype=torch.float64):
    path = f"{H5DIR}/GEO04_{bc}.h5"
    with h5py.File(path, "r") as f:
        coords = f["coords"][()].astype(np.float64)
        tet4 = f["tet4"][()].astype(np.int64)
        Ev = f["Material_E"][()].astype(np.float64)
        nuv = f["Material_nu"][()].astype(np.float64)
        loaded_force = f["loaded_force"][()].astype(np.float64)
        fixed_oh = f["Fixed_one_hot"][()]            # (N,6) int
        rubber_fixed = f["Rubber_fixed"][()]         # (N,) float
        disp_gt = f["DISP"][()].astype(np.float64)   # (N,11,3)

    N = coords.shape[0]

    # per-tet material = mean of its 4 node values (all aluminum anyway)
    E_tet = Ev[tet4].mean(axis=1)
    nu_tet = nuv[tet4].mean(axis=1)

    # fixed mask (translations only)
    fixed = (fixed_oh[:, :3] > 0)
    if include_rubber_fixed:
        rf = (rubber_fixed != 0)
        fixed = fixed | rf[:, None]

    # Pin isolated nodes (not referenced by any tet) -> they have zero
    # stiffness rows and make the global K singular. They are non-structural
    # (connector / virtual / label-0 E=0 nodes), so fixing them is safe.
    n_isolated = 0
    if pin_isolated:
        used = np.unique(tet4)
        iso_mask = np.ones(N, dtype=bool)
        iso_mask[used] = False
        fixed = fixed | iso_mask[:, None]
        n_isolated = int(iso_mask.sum())

    coords_t = torch.tensor(coords, dtype=dtype, device=device)
    tet_t = torch.tensor(tet4, dtype=torch.long, device=device)
    force_t = torch.tensor(loaded_force, dtype=dtype, device=device)
    fixed_t = torch.tensor(fixed, dtype=torch.bool, device=device)
    material = {
        "E": {"c3d4": torch.tensor(E_tet, dtype=dtype, device=device)},
        "nu": {"c3d4": torch.tensor(nu_tet, dtype=dtype, device=device)},
    }
    return dict(
        N=N, coords=coords_t, tet=tet_t, force=force_t, fixed=fixed_t,
        material=material, disp_gt=disp_gt, n_isolated=n_isolated, raw=dict(
            E=Ev, nu=nuv, fixed_oh=fixed_oh, rubber_fixed=rubber_fixed,
            loaded_force=loaded_force, coords=coords, tet4=tet4,
        ),
    )
