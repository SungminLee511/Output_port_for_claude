"""M1: symmetric N2S contact pairs from contact_edge_index.

Interfaces 1-2 and 2-3. For each:
  slave  = floater nodes that are cei endpoints (body1 / body3)
  master = body2 boundary tris whose 3 nodes are all body2 cei-endpoints
           of that interface (interface-local master surface)
Also save per-slave outward normal (from `normal`) and thickness offset.
"""
import h5py, numpy as np, time

H5 = "/home/sky/home/TRASHCAN/data_port/hl-mando/GEO04_BC01.h5"
OUT = "results/contact_pairs_v2.npz"


def tet_boundary_faces(tet):
    f = np.concatenate([
        tet[:, [0, 2, 1]], tet[:, [0, 1, 3]],
        tet[:, [0, 3, 2]], tet[:, [1, 2, 3]],
    ], axis=0)
    key = np.sort(f, axis=1)
    order = np.lexsort(key.T)
    ks = key[order]; fs = f[order]
    same = np.all(ks[1:] == ks[:-1], axis=1)
    dup = np.zeros(len(ks), bool)
    dup[:-1] |= same; dup[1:] |= same
    return fs[~dup]


def main():
    t0 = time.perf_counter()
    with h5py.File(H5, "r") as f:
        tet = f["tet4"][()]
        lab = f["labels"][()]
        cei = f["contact_edge_index"][()]
        normal = f["normal"][()]
        thick = f["self_contact_thickness"][()]
        fric = f["self_contact_friction"][()]
    bnd = tet_boundary_faces(tet)
    print(f"boundary tris: {bnd.shape[0]}  ({time.perf_counter()-t0:.1f}s)")

    a, b = cei[0], cei[1]
    la, lb = lab[a], lab[b]

    def interface(flo):
        # edges between floater `flo` and body2 (either direction)
        m = ((la == flo) & (lb == 2)) | ((la == 2) & (lb == flo))
        ea, eb = a[m], b[m]
        flo_nodes = np.unique(np.where(la[m] == flo, ea, eb))
        b2_nodes = np.unique(np.where(la[m] == 2, ea, eb))
        return flo_nodes, b2_nodes

    flo_mask_face = lab[bnd]  # (B,3)
    is_b2_face = (flo_mask_face == 2).all(axis=1)
    pairs = {}
    for flo in (1, 3):
        slave, b2set = interface(flo)
        b2set_mask = np.zeros(lab.shape[0], bool); b2set_mask[b2set] = True
        face_in = b2set_mask[bnd].all(axis=1)
        master = bnd[is_b2_face & face_in]
        pairs[flo] = dict(slave=slave, master=master)
        print(f"interface {flo}-2: slave={slave.size} body2set={b2set.size} master_tris={master.shape[0]}")

    np.savez(OUT,
             slave_1=pairs[1]["slave"], master_1=pairs[1]["master"],
             slave_3=pairs[3]["slave"], master_3=pairs[3]["master"],
             normal=normal, thickness=thick, friction=fric)
    print("saved", OUT, f"({time.perf_counter()-t0:.1f}s)")


if __name__ == "__main__":
    main()
