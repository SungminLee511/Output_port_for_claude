"""Build final RESULTS.md + per-sample GT-vs-solved point-cloud figures.

For each BC, picks the BEST round (lowest rel-L2) among results/<bc>_r*.json,
writes a metrics table to RESULTS.md, and renders figures/<bc>_cloud.png:
  panel 1 : GT deformed point cloud (colored by |disp|)
  panel 2 : solver deformed point cloud (same color scale)
  panel 3 : per-node error |u_sol - u_gt|
"""
import os, json, glob, re
import numpy as np
import matplotlib
matplotlib.use("Agg")
import matplotlib.pyplot as plt

ROOT = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
RES = os.path.join(ROOT, "results"); FIG = os.path.join(ROOT, "figures")
os.makedirs(FIG, exist_ok=True)
ALL_BCS = [f"BC{i:02d}" for i in range(1, 21)]
RNG = np.random.default_rng(0)


def best_round(bc):
    best = None
    for p in glob.glob(os.path.join(RES, f"{bc.lower()}_r*.json")):
        m = re.search(r"_r(\d+)\.json$", p)
        if not m:
            continue
        with open(p) as f:
            d = json.load(f)
        d["_round"] = int(m.group(1))
        d["_fields"] = p.replace(".json", "_fields.npz")
        if best is None or d["relL2_free"] < best["relL2_free"]:
            best = d
    return best


def cloud_fig(bc, d):
    f = np.load(d["_fields"]); u = f["u"]; u_gt = f["u_gt"]; coords = f["coords"]
    n = coords.shape[0]
    idx = RNG.choice(n, size=min(25000, n), replace=False)
    c = coords[idx]; us = u[idx]; ug = u_gt[idx]
    gm = np.linalg.norm(ug, axis=1); sm = np.linalg.norm(us, axis=1)
    err = np.linalg.norm(us - ug, axis=1)
    diag = np.linalg.norm(coords.max(0) - coords.min(0))
    amp = 0.15 * diag / (max(gm.max(), sm.max()) + 1e-30)
    vmax = max(gm.max(), sm.max())

    fig = plt.figure(figsize=(16, 5))
    specs = [("GT (deformed x%.0f)" % amp, c + amp * ug, gm, "viridis", 0, vmax),
             ("Solver (deformed x%.0f)" % amp, c + amp * us, sm, "viridis", 0, vmax),
             ("|u_sol - u_gt| (mm)", c + amp * ug, err, "inferno", 0, None)]
    for j, (title, pos, col, cmap, vmn, vmx) in enumerate(specs):
        ax = fig.add_subplot(1, 3, j + 1, projection="3d")
        p = ax.scatter(pos[:, 0], pos[:, 1], pos[:, 2], c=col, s=1.5,
                       cmap=cmap, vmin=vmn, vmax=vmx)
        ax.set_title(title, fontsize=10)
        ax.set_xticks([]); ax.set_yticks([]); ax.set_zticks([])
        fig.colorbar(p, ax=ax, shrink=0.6, pad=0.02)
    fig.suptitle(f"{bc}  k={d['k']:g}  relL2={d['relL2_free']:.3f} "
                 f"(scaled {d['relL2_scaled']:.3f})  dir-cos={d['dir_cos_mean']:.3f}",
                 y=1.02, fontsize=12)
    fig.tight_layout()
    out = os.path.join(FIG, f"{bc.lower()}_cloud.png")
    fig.savefig(out, dpi=95, bbox_inches="tight"); plt.close(fig)
    return os.path.basename(out)


rows = []
for bc in ALL_BCS:
    d = best_round(bc)
    if d is None:
        rows.append((bc, None)); continue
    png = cloud_fig(bc, d)
    rows.append((bc, d, png))
    print(f"{bc}: relL2={d['relL2_free']:.3f} scale={d['best_scale']:.3f} "
          f"dircos={d['dir_cos_mean']:.3f} k={d['k']:g} -> {png}", flush=True)

# write RESULTS.md
lines = ["# HL-Mando GEO04 — all 20 BC solves vs ground truth\n",
         "MESHnSOLVERS augmented-Lagrange contact + compliant rubber-spring "
         "grounding. Per-sample only the rubber spring k is calibrated "
         "(GT-informed); contact recipe (eps=5e4, mu=0.07, 2 load steps, AMG-PCG) "
         "is identical for every sample.\n",
         "## Metrics (best round per BC)\n",
         "| BC | k | rel-L2 | rel-L2 (1 scale) | best-scale | dir-cos | "
         "node-err mean (mm) | node-err p95 (mm) | solve s | target |",
         "|----|---|--------|------------------|-----------|---------|"
         "-------------------|------------------|---------|--------|"]
npass = 0
for r in rows:
    if r[1] is None:
        lines.append(f"| {r[0]} | – | (not solved) | | | | | | | – |"); continue
    bc, d, png = r
    ok = "✅" if d["relL2_free"] <= 0.30 else ("~" if d["relL2_scaled"] <= 0.30 else "✗")
    if d["relL2_free"] <= 0.30:
        npass += 1
    lines.append(f"| {bc} | {d['k']:g} | {d['relL2_free']:.3f} | "
                 f"{d['relL2_scaled']:.3f} | {d['best_scale']:.3f} | "
                 f"{d['dir_cos_mean']:.3f} | {d['node_err_mean']:.3f} | "
                 f"{d['node_err_p95']:.3f} | {d['solve_time_s']:.0f} | {ok} |")
solved = [r for r in rows if r[1] is not None]
if solved:
    avg_rel = np.mean([r[1]["relL2_free"] for r in solved])
    avg_dc = np.mean([r[1]["dir_cos_mean"] for r in solved])
    lines += [f"\n**Summary:** {len(solved)}/20 solved, {npass}/20 hit rel-L2 ≤ 0.30. "
              f"mean rel-L2 = {avg_rel:.3f}, mean dir-cos = {avg_dc:.3f}.\n",
              "Legend: ✅ rel-L2 ≤ 0.30 · ~ within target after one global scale "
              "(magnitude-only residual) · ✗ miss.\n",
              "## Per-sample point clouds (GT vs solver)\n"]
    for r in solved:
        lines.append(f"### {r[0]}\n![{r[0]}](figures/{r[2]})\n")
with open(os.path.join(ROOT, "RESULTS.md"), "w") as f:
    f.write("\n".join(lines))
print(f"\nwrote RESULTS.md ({len(solved)}/20 solved, {npass} pass)")
