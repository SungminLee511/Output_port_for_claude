"""GT-informed rubber-spring k calibration across rounds.

Reads results/<bc>_r<n>.json for all rounds, and for every BC that has not yet
hit rel-L2 <= TARGET proposes the next k and writes the next-round job JSON.

Model: solver/GT magnitude ratio r(k) = |u|/|u_gt| ~= 1/best_scale, and
r(k) = a + b/k  (a = structural compliance, b/k = rubber-pad compliance).
 - 1 data point  -> assume a~0:  k_next = k * r            (= k / scale)
 - >=2 points    -> fit a,b from last two rounds; solve r=1: k_next = b/(1-a)

Usage:  python calibrate.py <next_tag>   (e.g. calibrate.py r2)
Writes jobs/<next_tag>.json with cases{bc:k} for the BCs still missing target.
If none miss -> writes empty cases and prints ALL-PASS.
"""
import sys, os, json, glob, re

ROOT = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
RES = os.path.join(ROOT, "results")
JOBS = os.path.join(ROOT, "jobs"); os.makedirs(JOBS, exist_ok=True)
TARGET = 0.30
KMIN, KMAX = 1.0, 2000.0
ALL_BCS = [f"BC{i:02d}" for i in range(1, 21)]

next_tag = sys.argv[1] if len(sys.argv) > 1 else "r2"


def history(bc):
    """list of (round_int, k, relL2, scale) sorted by round."""
    h = []
    for p in glob.glob(os.path.join(RES, f"{bc.lower()}_r*.json")):
        m = re.search(r"_r(\d+)\.json$", p)
        if not m:
            continue
        with open(p) as f:
            d = json.load(f)
        h.append((int(m.group(1)), d.get("k", 5.0), d["relL2_free"], d["best_scale"]))
    return sorted(h)


def propose(h):
    """given history, propose next k (clamped)."""
    last_k, _, last_s = h[-1][1], h[-1][2], h[-1][3]
    r_last = 1.0 / max(last_s, 1e-6)
    if len(h) == 1:
        k = last_k * r_last                       # a~0 approximation
    else:
        k1, _, s1 = h[-2][1], h[-2][2], h[-2][3]
        k2, _, s2 = h[-1][1], h[-1][2], h[-1][3]
        r1, r2 = 1.0 / max(s1, 1e-6), 1.0 / max(s2, 1e-6)
        inv1, inv2 = 1.0 / k1, 1.0 / k2
        if abs(inv1 - inv2) < 1e-12:
            k = last_k * r_last
        else:
            b = (r1 - r2) / (inv1 - inv2)
            a = r1 - b * inv1
            denom = (1.0 - a)
            if abs(denom) < 1e-6 or b / denom <= 0:
                k = last_k * r_last
            else:
                k = b / denom
    return float(min(max(k, KMIN), KMAX))


cases = {}; summary = []
for bc in ALL_BCS:
    h = history(bc)
    if not h:
        summary.append(f"{bc}: (no result yet)"); continue
    best = min(h, key=lambda x: x[2])
    if best[2] <= TARGET:
        summary.append(f"{bc}: PASS  relL2={best[2]:.3f} (k={best[1]:g})")
    else:
        k_next = propose(h)
        cases[bc] = round(k_next, 2)
        last = h[-1]
        summary.append(f"{bc}: miss relL2={last[2]:.3f} scale={last[3]:.3f} "
                       f"k={last[1]:g} -> next k={k_next:.2f}")

job = {"tag": next_tag, "cases": cases}
with open(os.path.join(JOBS, f"{next_tag}.json"), "w") as f:
    json.dump(job, f, indent=2)

print("=== calibration summary ===")
for s in summary:
    print(" ", s)
print(f"\n{len(cases)} BC(s) need round {next_tag}: {list(cases)}")
if not cases:
    print("ALL-PASS")
print(f"wrote jobs/{next_tag}.json")
