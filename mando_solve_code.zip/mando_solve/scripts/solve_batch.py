"""Batch HL-Mando solver: solve a set of BCs at given rubber-spring k.

Reads a job JSON:  {"tag": "r1", "cases": {"BC03": 5.0, "BC04": 5.0, ...}}
Solves each BC with MESHnSOLVERS auglag contact + compliant rubber-spring
grounding (k from the job).  Saves results/<bc>_<tag>.json and _fields.npz.
Skips a case whose result already exists (resumable).

Fixed recipe (validated on BC01/BC05):  eps=5e4, mu=0.07, steps=2, nr_max=15,
al_outer=2, linear=amg.  Only the rubber spring k is calibrated per sample.
"""
import sys, os, time, json, argparse
import numpy as np, torch

ROOT = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))   # mando_solve/
sys.path.insert(0, os.path.join(ROOT, "scripts"))
sys.path.insert(0, "/home/sky/home/SOLVERX/MESHnSOLVERS")
from postprocess.solver import static_structure_solver_with_contact
from mando_loader import load_case

DEV = "cuda:0"; DT = torch.float64
EPS = 5e4; MU = 0.07; STEPS = 2; NR_MAX = 15; AL_OUTER = 2; MAX_ITER = 300

ap = argparse.ArgumentParser()
ap.add_argument("--job", type=str, required=True, help="job json with tag + cases{bc:k}")
args = ap.parse_args()

with open(args.job) as f:
    job = json.load(f)
tag = job["tag"]; cases = job["cases"]
RES = os.path.join(ROOT, "results")
cp = np.load(os.path.join(RES, "contact_pairs_v2.npz"))


def metrics(u, u_gt, fixed):
    free = ~fixed
    relL2 = np.linalg.norm((u - u_gt)[free]) / (np.linalg.norm(u_gt[free]) + 1e-30)
    a = u[free]; b = u_gt[free]
    s = float((a * b).sum() / ((a * a).sum() + 1e-30))
    relL2_s = np.linalg.norm((s * u - u_gt)[free]) / (np.linalg.norm(u_gt[free]) + 1e-30)
    gm = np.linalg.norm(u_gt, axis=1); sm = np.linalg.norm(u, axis=1)
    mv = gm > 0.01 * gm.max()
    cos = np.einsum("ij,ij->i", u[mv], u_gt[mv]) / (sm[mv] * gm[mv] + 1e-30)
    ne = np.linalg.norm(u - u_gt, axis=1)
    return dict(relL2_free=float(relL2), best_scale=s, relL2_scaled=float(relL2_s),
                dir_cos_mean=float(cos.mean()), node_err_mean=float(ne.mean()),
                node_err_p95=float(np.percentile(ne, 95)), node_err_max=float(ne.max()),
                gt_max=float(gm.max()), sol_max=float(sm.max()))


for bc, k in cases.items():
    out_json = os.path.join(RES, f"{bc.lower()}_{tag}.json")
    if os.path.exists(out_json):
        print(f"[skip] {bc} {tag} already done", flush=True); continue
    print(f"\n===== {bc}  tag={tag}  k={k} =====", flush=True)
    d = load_case(bc, include_rubber_fixed=False, device="cpu", dtype=DT)
    rf = d["raw"]["rubber_fixed"]
    spring_nodes = np.nonzero(rf != 0)[0].astype(np.int64)
    d["material"]["spring_nodes"] = torch.tensor(spring_nodes, dtype=torch.long, device=DEV)
    d["material"]["spring_k"] = float(k)
    pairs = [
        {"slave_nodes": torch.tensor(cp["slave_1"], dtype=torch.long, device=DEV),
         "master_faces": torch.tensor(cp["master_1"], dtype=torch.long, device=DEV)},
        {"slave_nodes": torch.tensor(cp["slave_3"], dtype=torch.long, device=DEV),
         "master_faces": torch.tensor(cp["master_3"], dtype=torch.long, device=DEV)},
    ]
    print(f"[setup] DOF={3*d['N']} spring_nodes={spring_nodes.size} k={k}", flush=True)
    t1 = time.perf_counter()
    u = static_structure_solver_with_contact(
        coords=d["coords"], force=d["force"], fixed=d["fixed"],
        contact_pairs=pairs, contact_epsilon=EPS,
        contact_method="auglag", al_max_outer=AL_OUTER, al_gap_tol=1e-4, al_alpha=1.0,
        mu_s=MU, mu_d=MU, friction_penalty_ratio=0.1,
        n_load_steps=STEPS, nr_tol=1e-3, nr_max_iter=NR_MAX,
        elements_volume={"c3d4": d["tet"]}, material=d["material"],
        dim=3, cg_start=True, linear_solver="amg", max_iter=MAX_ITER,
        tol=1e-6, device=DEV, dtype=DT)
    st = time.perf_counter() - t1
    u = u.detach().cpu().numpy(); u_gt = d["disp_gt"][:, 10, :]
    fixed = d["fixed"].numpy()
    m = metrics(u, u_gt, fixed)
    rep = dict(bc=bc, tag=tag, k=float(k), eps=EPS, mu=MU, steps=STEPS,
               solve_time_s=round(st, 1), **m)
    print(json.dumps(rep, indent=2), flush=True)
    with open(out_json, "w") as fp:
        json.dump(rep, fp, indent=2)
    np.savez(os.path.join(RES, f"{bc.lower()}_{tag}_fields.npz"),
             u=u, u_gt=u_gt, coords=d["raw"]["coords"])
    print(f"[done] {bc} {tag} relL2={m['relL2_free']:.3f} "
          f"scale={m['best_scale']:.3f} dircos={m['dir_cos_mean']:.3f} {st:.0f}s", flush=True)

print("\nBATCH COMPLETE", flush=True)
