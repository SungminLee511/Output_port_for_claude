# HL-Mando Solve Plan v2 — Augmented-Lagrange contact upgrade + mapping campaign

**Goal:** make MESHnSOLVERS reproduce the HL-Mando GT displacement
"well enough to say it kinda works" (target rel-L2 ≲ 0.3, dir-cos ≳ 0.9 on
BC01, ideally ≲ 0.15). Route chosen: **upgrade the contact solver to
Augmented-Lagrange (Uzawa) normal contact** (option *a*), eliminating the
penalty-stiffness accuracy/conditioning trap, then run an exhaustive
H5→solver mapping campaign on the Mando data.

Execution: **small relay steps** (Pattern B, 30 s auto-wakes). Long solves
use Pattern A wakes. Each step is self-contained, leaves a checkpoint, and
reports rel-L2 vs `DISP[:,10]`.

---

## Background (from v1 campaign — why we are here)

- Data = **3 disconnected bodies** (labels 1/2/3), Al E=72.3 GPa, ν=0.33.
  body2 = anchor (535 fixed + main load); body1/body3 = floaters held only
  by **frictional self-contact** vs body2.
- GT (`DISP[:,10]`) = final of a **near-linear 11-step ramp** → ~linear
  elastic. Dataset ships full Abaqus contact data: `self_contact_friction`,
  `self_contact_thickness`, `normal`, `COPEN`, `CPRESS`, `contact_edge_index`.
- v1 scores (rel-L2, free DOFs): linear no-contact = blow-up; N2S μ=0.07 =
  5.03; N2S μ=2.0 = 3.15; bonded-tie k=1e6 = 1.20, k=1e8 = 1.11 (dir-cos
  0.90). **Penalty stiffness saturated accuracy at ~1.1** but k=1e6 broke CG
  (didn't converge); k=1e8 converged. → classic penalty trap. body2 alone
  (linear) = 0.47 but CG hit maxiter.
- Diagnosis: penalty contact can't ride the accuracy-vs-conditioning
  tradeoff. **AL fixes exactly this.**

---

## Current solver facts (read before editing)

- `static_structure_solver_with_contact` @ `postprocess/solver.py:1296`.
  Pure-penalty N2S + penalty-regularised Coulomb friction; incremental
  load stepping + Newton-Raphson per step; F-β backtracking line search.
- Normal contact assembled in `compute_contact_apply_tensors` @ :1076 —
  `f_mag = ε·gap`, `K_ss = ε·nnᵀ`. **This is the AL injection point.**
- Active-set contact detection: `check_contact_igl_v2` @ :864.
- Friction: `compute_friction_apply_tensors` @ :1151 (Python per-slave loop —
  slow but works; leave for now).
- Comment @ :1330 notes a stripped "Alart-Curnier normal-AL Uzawa" path —
  AL is **not** currently active (`:1869` "Pure penalty … no AL multiplier").
- Linear solve: built-in CG (`cg_start=True`); cuSOLVER spsolve OOMs at
  580k DOF; Jacobi-PCG works but CG default maxiter too low.

---

## PART U — Solver upgrade to Augmented-Lagrange normal contact

> Done on a git branch in MESHnSOLVERS. Keep penalty path as default;
> AL behind `contact_method="auglag"`.

- **U0** — Create branch `auglag-contact`; snapshot current solver; confirm
  the two scratch fixes from v1 (top-level `import scipy`; cupy `cg(tol=)`)
  are present/needed. Write a 1-cube-on-cube toy fixture for later tests.
- **U1** — Add AL scaffolding to `static_structure_solver_with_contact`:
  new kwargs `contact_method="penalty"`, `al_max_outer=10`,
  `al_gap_tol=1e-4` (max penetration target, mm), `al_alpha=1.0`.
  Per-pair `lambda_N` store keyed by slave global idx, init 0, persisted
  across the outer Uzawa loop (not reset per load step).
- **U2** — Generalise `compute_contact_apply_tensors`: accept optional
  `lambda_N` (per-active-slave). Compute Alart-Curnier normal pressure
  `p = relu(lambda_N + ε·gap)`; `f_mag = p`; gate `K_ss=ε·nnᵀ` to the
  active set `lambda_N + ε·gap > 0`. `lambda_N=None` ⇒ exact penalty path
  (backward compatible).
- **U3** — Wrap the per-load-step NR loop in an **outer Uzawa loop** (only
  when `contact_method="auglag"`): run NR to equilibrium, then update
  `lambda_N ← relu(lambda_N + ε·gap)` per active slave, recompute max
  penetration; repeat until `max_pen < al_gap_tol` or `al_max_outer`.
- **U4** — Toy verification: cube pressed onto a fixed block. Assert (a)
  penetration → < al_gap_tol with *moderate* ε (e.g. 1e4), (b) contact
  pressure ≈ applied load / area, (c) ε-insensitivity of the converged
  displacement (1e3 vs 1e5 agree). This is the proof AL beats penalty.
- **U5** — Linear-solver robustness: bump CG maxiter + Jacobi precond as
  default inside the contact solver; add optional `pyamg` AMG precond if
  importable; verify body2-alone (580k DOF) converges (residual < tol).
- **U6** — Run existing MESHnSOLVERS contact unit tests; ensure penalty
  path unchanged (no regression). Commit branch.

## PART M — Mando mapping & solve campaign (BC01 first)

> All in `.tmpwork/`, results to `.tmpwork/results/`. Each step = one solve
> + one metrics JSON + a one-line verdict.

- **M1** — Build **symmetric contact pairs from `contact_edge_index`** for
  BOTH interfaces (1–2 and 2–3): floater nodes = slaves, body2 boundary
  faces = masters (reuse `build_master_surf.py`, extend to use the
  dataset's own pair list + `normal` for orientation + `self_contact_thickness`
  as initial gap offset). Save `contact_pairs_v2.npz`.
- **M2** — **AL frictionless** solve on BC01 (moderate ε=1e4, al_gap_tol=1e-4,
  load steps=5). Metric vs GT. Expect big improvement over penalty.
- **M3** — Add **friction** from `self_contact_friction` (per-pair μ; map to
  mu_s=mu_d). Re-solve. Metric.
- **M4** — Mapping variants (one small step each, keep best):
  - M4a: include `Rubber_fixed` (725 nodes) as extra fixed BC.
  - M4b: contact thickness offset on/off (use `self_contact_thickness`).
  - M4c: faithful load path — ref-node 6-DOF `load` + reconstruct RBE2/RBE3
    from `*_edge_index` instead of pre-distributed `loaded_force`.
  - M4d: compare against intermediate DISP steps / load fractions (rule out
    load-magnitude mismatch).
  - M4e: master/slave role swap + two-pass symmetric contact.
- **M5** — Tuning sweep on the best variant: ε ∈ {1e3,1e4,1e5} (confirm AL
  ε-insensitivity), load steps ∈ {1,5,10}, al_max_outer, gap_tol. Lock best.
- **M6** — Per-body error breakdown (body1/2/3 scale + dir-cos) on the best
  solve; decide "kinda works?" against target.

## PART R — Validation, scale-out, report

- **R1** — Best-case figure: GT vs solved (per-node scatter, magnitude hist,
  rel-L2 bar across methods incl. new AL). Push to `output_port`.
- **R2** — If best BC01 rel-L2 ≲ 0.3: run 3–4 more BCs (e.g. BC02/05/10) to
  show it generalises; tabulate.
- **R3** — Final verdict written into this file (§ Results); push figures;
  clean scratch logs. If still failing, honest negative verdict + the
  specific remaining gap (e.g. true mortar S2S needed).

---

## Decision log / open knobs
- AL `al_alpha` (multiplier update relaxation) — start 1.0 (Uzawa).
- ε now a *conditioning* knob, not accuracy — pick for solver speed.
- Friction: normal-AL first; tangential-AL only if M3 friction is unstable.
- Stop campaign when target met OR mapping space exhausted with honest gap.

## Relay protocol
- After each step: report `step id | what done | rel-L2 / status | next`,
  then schedule `wake_after.sh 30 "RELAY: proceed to next step."`.
- Long solves (>10 min): Pattern A wake at ETA; relay timer pauses.
- Unlimited relay (no kill-switch) — runs until plan exhausted, target met,
  unresolved error, or user interrupts.

---

## Results

### U4 — AL contact verified (box-on-plate baseline)
- Penalty maxdisp swings 43× with ε (5.07e-3 @ε1e4 → 1.17e-4 @ε1e6).
- AL maxdisp eps-insensitive (6.72e-5 vs 6.69e-5, 0.4%).
- AL penetration 6.9e-6 < tol in 2 Uzawa passes; 450× less than penalty.

### U5 — Linear-solver robustness
- Jacobi-PCG (GPU): INSUFFICIENT — body2-alone (370k DOF) stalls at maxiter=5000.
- AMG-PCG (pyamg SA, **rigid-body-mode near-nullspace**, CPU): converges body2 in
  **52 iters, res 1.3e-5, 15.7s**. Default (constant) nullspace was the bug — stalled at 500 iters.
- Integrated as opt-in `linear_solver="amg"` in contact solver. Validated: AMG == CG on
  baseline (maxdisp 6.6874e-05 both), AMG 2 iters/NR.
- NOTE: body2 relL2 vs GT ≈ 4 (disp ~7× too large) — a **mapping** issue, addressed in PART M.

### M1 — Symmetric contact pairs (contact_pairs_v2.npz)
- cei: 3627 edges (1-2) + 2562 (2-3). Interface 1-2: 2180 slaves / 2191 master tris;
  interface 3-2: 1455 slaves / 1598 master tris. thickness uniform 1.0, friction uniform 0.07.

### M2 — AL frictionless (FAILS, as theory predicts)
- 581895 DOF, eps=1e4, 1 step, AMG. relL2=148, best_scale=1.2e-3, dir_cos=0.67.
- Floaters (body1/3) have NO tangential constraint → rigid sliding modes → K singular
  tangentially. AMG hits maxiter (~8min/solve uncapped), NR never converges (Rel~0.5),
  Uzawa penetration DIVERGES (1.6→17.5). Frictionless is ill-posed for floaters → need friction.

### M3 — AL + friction μ=0.07 (stalls)
- Floaters fully SLIP (Stick 0/2039) at eps=1e4 — normal pressure too low → friction cap tiny.
  NR plateaus Rel~0.45, Uzawa can't advance. Need higher eps and/or body1 grounding.

### M4 — Diagnostic deep-dive (body2 magnitude root cause)
- Load magnitude CORRECT: loaded_force resultant 29810 ≈ ref-node `load` 30060; K·u_GT at
  loaded nodes ≈ f_ext. Not a load error.
- **Isolated body2 over-deflects 5.8×** (max|u|=2.44 vs GT 0.43), relL2_scaled=0.72 (wrong SHAPE,
  not just scale) — even with GT prescribed at the 535 fixed nodes (still 5.8×).
- Root cause: body2 fixed nodes cluster at ONE END (y∈[-289,-263] of 508 span) → **cantilever**.
  In the real assembly its far end is supported via contact with floaters; isolated → soft.
- **Grounding map**: body1 has 719 Rubber_fixed (compliant ground) we were IGNORING;
  body2 535 fixed; body3 ungrounded (held by contact only). GT|u|: body1 0.32, body2 0.25, body3 0.32.
- CONCLUSION: per-body validation invalid; must solve full coupled multi-body WITH body1
  rubber grounding ON + friction. Next: grounded full solve.

### M4-grounded — BREAKTHROUGH (body1 rubber grounding ON)
- Full coupled solve, body1 Rubber_fixed ON, eps=5e4, μ=0.07, 2 steps, AMG.
- **relL2 148 → 0.74**, **best_scale 0.0012 → 0.87** (magnitude now ≈ correct — body2
  cantilever supported via contact with grounded body1). dir_cos 0.59.
- Still short of target (relL2≤0.3, dir_cos≥0.9). NR not converged (Rel~0.8), friction
  all-slip at μ=0.07. Shape/direction error remains → M5 tuning (load steps, eps, NR iters).

### M5 — Tuning (PAUSED mid-solve, 2026-06-23)
- Tried: `m2_solve.py --tag m5tune --rubber --eps 1e5 --mu 0.07 --steps 3
  --nr_max 12 --al_outer 2 --max_iter 300` (pid was 932837, KILLED on pause).
- Behaviour: NR **does not converge** — Rel plateaus ~0.85, contact goes
  **all-slip** (Stick 0/2039) even at eps=1e5. F-β line search keeps rewinding
  (damping→0.15..0.5), AL outer pass-1 max_penetration 2.7e-2 ≫ tol 1e-4.
  AMG itself is fine (174–184 iters, res 1e-7). So linear solve OK; the
  **nonlinear friction/contact equilibrium** is the wall.

### M5c — friction maxed (μ=0.5, eps=1e5, 4 steps) — plateau confirmed
- relL2 0.80 (WORSE than M4grounded 0.74). Higher μ improved direction
  (dir_cos 0.59→0.72) but collapsed magnitude (best_scale 1.59, sol too small).
  NR still didn't converge; penetration 0.11 ≫ tol. **Friction tuning plateaus
  ~0.74–0.80 → not the lever.** (m5b @ steps=8 killed: 5h ETA, same all-slip.)

### M6 — per-body breakdown → ROOT CAUSE FOUND (body1 grounding wrong)
Per-body relL2/dir_cos on best result (M4grounded):
- **body2** (anchor, 123k nodes): relL2 0.565, dir_cos 0.885, scale 0.90 — GOOD.
- **body3** (13k, contact-grounded only): relL2 0.346, dir_cos 0.956 — EXCELLENT.
- **body1** (57k): relL2 1.017, dir_cos **−0.123**, |u|sol 0.016 vs GT 0.322 — FROZEN/wrong.
- **The entire error is body1.** body2/body3 are essentially solved.
- WHY: `Rubber_fixed` is a 0/1 MASK (719 nodes, all body1) and **GT moves those
  nodes 0.31** — they are NOT rigid; they are a COMPLIANT rubber pad. body1 has
  ZERO hard-fixed nodes (rubber is its only ground). We modelled rubber as rigid
  u=0 → froze body1's grounded end → body1 wrong → drags coupled solve.
- FIX = compliant **spring-to-ground** on body1 rubber nodes (NOT tangential-AL).
  Solver already supports it: `material["spring_nodes"]`+`["spring_k"]` bakes k·I
  into K_base. This also kills body1's rigid-mode singularity that broke NR.
  Added `--rubber_k` flag to `m2_solve.py` (rubber nodes free + soft springs).
  Calibrating k (start 1e2) replicating M4grounded params (eps5e4, μ0.07, 2 steps).

### M7 — rubber SPRING grounding k-sweep → BREAKTHROUGH (target essentially met)
Replicate M4grounded params (eps5e4, μ0.07, 2 steps, AMG) but rubber = soft springs.
| k (N/mm/node) | overall relL2 | dir_cos | scale | body1 |u| (GT 0.322) | body1 relL2/dircos |
|---|---|---|---|---|---|
| rigid (∞) | 0.740 | 0.589 | 0.87 | 0.016 (frozen) | 1.02 / −0.12 |
| 100 | 0.789 | 0.626 | 0.84 | 0.072 | 1.03 / 0.11 |
| **10** | **0.343** | **0.948** | **1.05** | **0.258** | 0.436 / 0.906 |
- **k=10 is the breakthrough**: relL2 0.74→**0.343**, dir_cos 0.59→**0.948** (≥0.9 target MET),
  magnitude near-perfect (scale 1.05). Per-body: body2 0.261/0.969, body3 0.408/0.912,
  body1 0.436/0.906 — ALL bodies now aligned. body1 still slightly under-deflects
  (|u| 0.258 vs 0.322, scale 1.13) → trying k=5 to push body1 to full 0.32 and
  break relL2 < 0.3. Root cause (rigid rubber) confirmed solved by compliant springs.
- Solve time ~48 min/run (eps5e4, 2 steps, AMG, k=10).

---

## ✅ TARGET MET (2026-06-23) — best = AL + rubber springs k=5

**relL2 0.282 (≤0.30 ✓), dir_cos 0.957 (≥0.90 ✓)** on BC01, fields in
`results/bc01_m7k5_fields.npz`. R1 figure pushed to output_port
(`bc01_verdict_t20260623b.png`). Now running **R2** generalisation (BC02/05/10
with the same k=5 config). Then R3 final verdict.

**The fix that worked:** AL normal contact (done in PART U) + treating
`Rubber_fixed` as a COMPLIANT spring pad (k=5 N/mm/node via
`material["spring_nodes"]`) instead of a rigid u=0 BC. The rigid BC froze body1
(the entire residual error); springs let body1 ride the contact like body3.
The earlier all-slip/NR-stall obsession was a red herring — friction tuning
plateaued ~0.74–0.80; the real bug was the grounding model.

---

## ⏸️ (historic) CAMPAIGN PAUSE CHECKPOINT (pre-breakthrough)

**Where we are:** best result is **M4-grounded** (relL2 **0.74**, best_scale
0.87, dir_cos 0.59) — magnitude basically right after turning ON body1 rubber
grounding; remaining error is **shape/direction**, driven by NR not reaching
equilibrium and friction collapsing to all-slip.

**What was running when paused:** M5 tuning solve (killed). No wake pending
(wake sleeper killed too). Nothing running now.

**Files / state on disk (`.tmpwork/`):**
- `m2_solve.py` — the workhorse solver script (despite name, runs all M-steps
  via flags; `--rubber` = body1 grounding, `--tag` = output name).
- `build_contact_v2.py` → `results/contact_pairs_v2.npz` (symmetric pairs, M1).
- `results/bc01_m4*.json`, `*_fields.npz` — M4-grounded best fields.
- `mando_loader.py` — `load_case("BC01", include_rubber_fixed=...)`.
- Solver branch `auglag-contact` in MESHnSOLVERS (AL + AMG, committed 5f832a2).

**Next actions when resuming (M5 → M6 → PART R):**
1. **Fix all-slip / NR convergence** (the real blocker, not eps):
   - Try **higher μ** (0.2–0.5) so friction can actually carry tangential load,
     and/or **more load steps** (5–10) for gentler ramp so NR converges per step.
   - Consider **tangential-AL** (plan §M3 note) instead of penalty friction if
     slip persists — penalty-friction cap is too soft at low normal pressure.
   - Loosen F-β so it stops over-damping; raise `nr_max` to ~25.
2. Re-score vs `DISP[:,10]` (relL2 free, best_scale, dir_cos). Target ≤0.3 / ≥0.9.
3. If a variant beats 0.74 → M6 per-body breakdown, then PART R (figure to
   output_port, generalise to BC02/05/10, final R3 verdict).
4. If shape error won't close with friction tuning → honest verdict: true
   **mortar S2S** contact likely needed (penalty/AL N2S point contact insufficient).

**One-liner to resume a solve:**
```bash
cd /home/sky/home/.tmpwork && nohup ~/miniconda3/envs/SML_env/bin/python -u \
  m2_solve.py --tag m5b --rubber --eps 1e5 --mu 0.3 --steps 8 --nr_max 25 \
  --al_outer 3 --max_iter 300 > m5_solve.log 2>&1 &
```

---

## R3 — Final verdict: generalisation across BCs (k=5 fixed from BC01)

Took the BC01-tuned recipe **verbatim** (AL contact + compliant rubber-spring
grounding k=5 N/mm/node, eps=5e4, μ=0.07) and ran it on BC02/05/10 with **no
re-tuning**. Result splits cleanly into *direction* vs *magnitude*:

| BC | relL2 (free) | relL2 (best-scale) | best_scale | dir-cos | verdict |
|----|------|------|------|------|---|
| BC01 | **0.282** | 0.27 | ~0.95 | **0.957** | ✓ target met |
| BC05 | **0.244** | 0.222 | 0.906 | **0.974** | ✓ target met |
| BC02 | 1.25 | ~0.35 | 0.43 | **0.917** | direction ✓, 2.3× over-deflect |
| BC10 | 1.59 | 0.363 | 0.375 | **0.945** | direction ✓, 2.7× over-deflect |

**The honest story:**
1. **Direction generalises perfectly.** dir-cos ≥ 0.92 on *every* BC and every
   body — the AL contact coupling + rubber-pad compliance reproduce the correct
   deformation *shape* regardless of load case.
2. **Magnitude is BC-dependent → k=5 is overfit to BC01's load level.** BC01 and
   BC05 share a similar net-force / stiffness ratio, so the single calibrated
   spring constant lands them both at relL2 ≈ 0.25. BC02 and BC10 push harder on
   the rubber pad, so a fixed k=5 lets body1 ride ~2.3–2.7× too far; once you
   remove that single global scale (best-scale column) **all four collapse to
   relL2 ≈ 0.27–0.36** — i.e. the residual is almost entirely one scalar.
3. **Root physical limitation:** the rubber pad was given as a 0/1 mask with **no
   stiffness value**. We inferred k from BC01. A *correct* model needs the pad's
   real modulus (or a per-BC-independent k from the rubber geometry/material),
   which would close the magnitude gap without per-load calibration.

**Bottom line:** the contact solver itself is validated — AL-N2S + AMG-PCG
reproduces HL-Mando's 3-body contact deformation **shape** to dir-cos ~0.95
across all tested BCs, and hits the **relL2 ≤ 0.30** target on the BCs whose load
matches the rubber-spring calibration (BC01, BC05). The remaining error on
heavier-load BCs is a **single missing material constant** (rubber pad stiffness),
not a solver/contact deficiency. No mortar S2S upgrade was needed — the earlier
"true S2S required" worry was wrong; the plateau was the rigid-rubber modelling
bug, now fixed.

Per-body (BC10, heaviest): body1 dircos 0.959, body2 0.938, body3 0.935 —
shape good everywhere, magnitude uniformly ~2.7× (scale 0.37) → confirms a single
global compliance scalar, not localised error.
